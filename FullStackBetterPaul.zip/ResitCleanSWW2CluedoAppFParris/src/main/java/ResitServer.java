//This is the server MAIN class.
//It provides a service to ACCESS the Resit database.
//author: 2252544

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

//Notes:
//The postgresql-42.6.0 (8).jar is our JDBC DRIVER - (Jar = Driver)


public class ResitServer {

    private int thePort = 0;
    private String theIPAddress = null;
    private ServerSocket serverSocket =  null;


    public ResitServer(){                     //<<This is the Class CONSTRUCTOR
        //Initialize the TCP socket            //It creates the SERVER SOCKET
        thePort = Credentials.PORT;            //Reads the connection credentials from class Credentials
        theIPAddress = Credentials.HOST;

        //Initialize the SOCKET and runs the SERVICE LOOP
        System.out.println("Server: Initializing server socket at " + theIPAddress +
                " with listening port " + thePort);
        System.out.println("Server: Exit server application by pressing Ctrl+C (Windows or Linux) " +
                "or Opt-Cmd-Shift-Esc (Mac OSX)." );

        //^^ This is the part where our app will run indefinitely until 'Ctrl+C' is pressed


        try {
            //Initialize the socket
            int  backlog = 5; //<<Declares an integer variable named
                              // backlog and initializes it with the value 5
            serverSocket = new ServerSocket(thePort, backlog, InetAddress.getByName(theIPAddress));
            System.out.println("Server: Server at " + theIPAddress + " is listening on port : " + thePort);
        } catch (Exception e){
            //The creation of the server socket can cause several exceptions;
            //See https://docs.oracle.com/javase/7/docs/api/java/net/ServerSocket.html
            System.out.println(e);
            System.exit(1);
        }
    }

    //METHOD that EXECUTES the service loop:
    public void executeServiceLoop()  //This is the part that needs to run on an INFINITE loop
                                              //THE SERVICE WILL RUN INDEFINITELY BASED ON THIS CODE:
    {
        System.out.println("Server: Start service loop.");
        try {
            //Service loop
            while (true) {
                //Listens for requests from the client:
                Socket dbSocket = this.serverSocket.accept();

                //WAITS, then once it receives the request; creates a THREAD:
                ResitService queryThread = new ResitService(dbSocket);


            }
        } catch (Exception e){
            //The creation of the server socket can cause several exceptions;
            //See https://docs.oracle.com/javase/7/docs/api/java/net/ServerSocket.html
            System.out.println(e);
        }
        System.out.println("Server: Finished service loop.");
    }


    public static void main(String[] args){
        //Run the server
        ResitServer server = new ResitServer(); //inc. Initializing the socket
        server.executeServiceLoop();
        System.out.println("Server: Finished.");
        System.exit(0);
    }
}


//For closing the server - private boolean keypressedFlag = false;


