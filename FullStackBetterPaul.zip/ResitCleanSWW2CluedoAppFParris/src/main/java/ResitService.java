//This service THREADS to the Resit DATABASE SERVER.
//This class; 'ResitService' implements the database access service, i.e. opens a JDBC CONNECTION
//to the database, MAKES and RETRIEVES the query, then SENDS BACK the result.
//author: 2252544

import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetFactory;
import javax.sql.rowset.RowSetProvider;
import java.io.*;
import java.net.Socket;
import java.sql.*;
import java.time.format.DateTimeFormatter;


public class ResitService extends Thread{

    private Socket serviceSocket = null;
    private String[] requestStr  = new String[3]; //One slot for weapon, one for place and one for time.
    private ResultSet outcome    = null;

    //Establish CONNECTION with the DATABASE using the JDBC:
    private String USERNAME = Credentials.USERNAME;
    private String PASSWORD = Credentials.PASSWORD;
    private String URL      = Credentials.URL;    //Ok to not have the whole Driver import statement
                                                  //here as it will go to the 'credentials' class and
                                                  //read the URL path from there to connect to the
                                                  //database **I THINK*

    public void publicConnection() {



        try {
            // 2. Initialize driver
            Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



    //Class constructor
    public ResitService(Socket startSocket){
        //INITIATE a thread here:
        serviceSocket = startSocket;
        this.start();

    }


    //Retrieve the REQUEST from the socket:
    //(These are our service requests)
    public String[] retrieveRequest() //<<This is where all our query
    // elements will grab each piece of data from
    //each respective table.
    {
        this.requestStr[0] = ""; //For weapon
        this.requestStr[1] = ""; //For place
        this.requestStr[2] = ""; //For time

        String tmp = "";       //ALL these 'tmp's are STRING VARIABLES
        String tmp2 = "";
        String tmp3 = "";
        StringBuffer tsbCharacter;
        StringBuffer tsbOwnsWeapon;
        try {
            //Request STREAM NEEDS TO BE RECEIVED:
            InputStream inputStream = this.serviceSocket.getInputStream();
            InputStreamReader fullRequestReader = new InputStreamReader(inputStream);
            //String object that can be modified according to the request (each query the user makes
            // as detective) so 'character','ownsWeapon','wasInPlace' > for each of our attempts for
            //identifying the murderer:
            tsbCharacter = new StringBuffer();
            tsbOwnsWeapon = new StringBuffer();
            StringBuffer tsbWasInPlace = new StringBuffer();
            StringBuffer stringBuffer = new StringBuffer();
            char x;

            //Each char is read until '#' and then a full request is made
            boolean characterComplete = false;
            while (true) {
                try {
                    x = (char) fullRequestReader.read();


                    if (x == '#') {
                        break;
                    }
                    stringBuffer.append(x);

                    if (!characterComplete) {
                        characterComplete = true;
                    } else {
                        tsbOwnsWeapon = tsbOwnsWeapon.replace(0, 1, "");
                        characterComplete = false;
                    }

                    if (!characterComplete) {
                        tsbCharacter.append(x);
                    } else {
                        tsbOwnsWeapon.append(x);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
                /*{
                 tsbCharacter.append(x);
                }
                  else
                {
                    tsbOwnsWeapon.append(x);
                }
                else
                {
                    tsbWasInPlace.append(x);
                }

                 */
        //^Not sure if I need to have another if else for the third part of
        //a query which is the 'wasinplace' part.


        //NEEDS TO THEN CONVERT TO STRINGS:
        tmp = tsbCharacter.toString();
        tmp2 = tsbOwnsWeapon.toString();

        //tmp3 = tsbWasInPlace.toString();

        //StringBuffer tsbFullRequest = new StringBuffer(); -Don't know what 'FullRequest' is referring to...

        //Add the request to the array:
        requestStr[0] = tmp;
        requestStr[1] = tmp2;


        //TO BE COMPLETED - this is where we process our QUERY:

        //}catch(IOException e){
        //System.out.println("Service thread " + this.getId() + ": " + e);
        //}
        return this.requestStr;
    }


     //ATTEND THE REQUEST:
                                           //(Parse the request command and execute the query)
    public boolean attendRequest()
    {
        boolean flagRequestAttended = true;
        this.outcome = null;

        //Step 3. PREPARE our SQL Statement-

        try {
            Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            Statement stmt = connection.createStatement();
            String sql = "SELECT character.name, character.age " +
                    "FROM character " +
                    "LEFT JOIN ownsweapon ON character.name = ownsweapon.name " +
                    "LEFT JOIN wasinplace ON character.name = wasinplace.name " +
                    "WHERE (ownsweapon.weapon = ? OR ownsweapon.weapon IS NULL)" +
                    "AND (wasinplace.place = ? OR wasinplace.place IS NULL) " +
                    "AND (wasinplace.visittime = ? OR wasinplace.visttime IS NULL)";


        //TO BE COMPLETED - Update this line as needed.

        System.out.println(sql);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");




            //Step 4. EXECUTE the query:

            //ResultSet rs = stmt.executeQuery(theQuery);
            PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);              //<<THIS IS THE PART THAT IS ROBUST TO SQL INJECTION!

            statement.setString(1, requestStr[0]);  // weapon
            statement.setString(2, requestStr[1]);  // place
            statement.setString(3, requestStr[2]);  // time
            ResultSet resultSet = statement.executeQuery();

            //PROCESS the query;
            RowSetFactory aFactory = RowSetProvider.newFactory();
            CachedRowSet crs = aFactory.createCachedRowSet();
            crs.populate(resultSet);


            //The output 'ResultSet' needs to be processed
            //TO BE COMPLETED -                                            //and the corresponding rows to the query need
            //to be fetched
            // Watch out! You may need to reset the iterator of the row set.


            //If a field is 'null' in the database,
            //then value returned by a getInt method
            //will be 0.
            resultSet.beforeFirst();                                        //for a 'getObject' method - if the FIELD is
            outcome = crs;                                                  //'null' then the object VALUE RETURNED will be
            StringBuilder tmp = new StringBuilder();                        //null as well.


            int count = stmt.executeUpdate(sql);
            System.out.print("Inserted " + count + " records successfully");


            while (this.outcome.next()) {
                tmp.append(outcome.getString("age")).append("\n");

            }

            System.out.println(tmp);


            //CLOSE your ResultSet and Statement Objects:
            //rs.close();
            //stmt.close();
            resultSet.close();                                        //Once the 'ResultSet' and 'Statement' objects
            statement.close();                                        //have been USED, they must be CLOSED EXPLICITLY
            connection.close();
            }                                                            // This is done by calls to the close() method:

        catch (Exception e) {
            System.out.println(e);
        }

        return flagRequestAttended;
    }



    //Wrap and return service outcome
    public void returnServiceOutcome(){
        try {
            //create a stream of characters
            OutputStream dbResponse = this.serviceSocket.getOutputStream();
            ObjectOutputStream dbWriter = new ObjectOutputStream(dbResponse);

            //Object needs to be 'WRITTEN':
            dbWriter.writeObject(outcome);

            //String then needs to be 'FLUSHED'
            dbWriter.flush();

            //TO BE COMPLETED

            System.out.println("Service thread " + this.getId() + ": Service outcome returned; " + this.outcome);

            //Terminating connection of the service socket
            serviceSocket.close();


        }catch (IOException e){
            System.out.println("Service thread " + this.getId() + ": " + e);
        }
    }


    //The service thread run() method
    public void run()
    {
        try {
            System.out.println("\n============================================\n");
            //Retrieve the service request from the socket
            this.retrieveRequest();
            System.out.println("Service thread " + this.getId() + ": Request retrieved: "
                    + "weapon->" + this.requestStr[0]
                    + "; place->" + this.requestStr[1]
                    + "; time->" + this.requestStr[2]);

            //Attend the request
            boolean tmp = this.attendRequest();

            //Send back the outcome of the request
            if (!tmp)
                System.out.println("Service thread " + this.getId() + ": Unable to provide service.");
            this.returnServiceOutcome();

        }catch (Exception e){
            System.out.println("Service thread " + this.getId() + ": " + e);
        }
        //Terminate service thread (by exiting run() method)
        System.out.println("Service thread " + this.getId() + ": Finished service.");
    }

}