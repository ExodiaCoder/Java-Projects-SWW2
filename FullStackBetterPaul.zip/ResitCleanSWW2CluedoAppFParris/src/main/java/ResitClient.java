//ResitClient.java
//This is a client for accessing the RESIT DATABASE
//Below is some simple JavaFX code for connecting to the database SERVER and INTERACTING with the database.
//author: 2252544

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javax.sql.rowset.CachedRowSet;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLException;



public class ResitClient extends Application {

    public static ResitClient me; //Get the application instance in javafx
    public static Stage thePrimaryStage;  //Get the application primary scene in javafx
    private Socket clientSocket = null;

    private String userCommand = null; //The user command

    private CachedRowSet serviceOutcome = null; //The service outcome


    //Convenient to populate the TableView
    public class MyTableRecord {
        private StringProperty age; //Just doing 'Age' as our TableView output

        public void setAge(String value) { ageProperty().set(value); }
        public String getAge() { return ageProperty().get(); }


        public StringProperty ageProperty() {
            if (age == null)
                age = new SimpleStringProperty(this, "");
            return age;
        }
    }


    //Class Constructor:

    public ResitClient()
    {me = this;}


    //INITIALIZES the client SOCKET using the credentials from class Credentials.
    public void initializeSocket(){

        try {
            clientSocket = new Socket(Credentials.HOST, Credentials.PORT);
        }catch (UnknownHostException e) {
            System.out.println("Client failed to initialize socket (unknown host): " + e);
        }catch (IOException e){
            System.out.println("Client failed to initialize socket (I/O Error): " + e);
        }

    }


    public void requestService() {
        try {
            System.out.println("Client: Requesting service for user command\n" + this.userCommand +"\n");

            //TO BE COMPLETED
            //Stream of characters with the request details:
            OutputStream queryStream = this.clientSocket.getOutputStream();
            OutputStreamWriter queryStreamWriter = new OutputStreamWriter(queryStream);

            //Terminating character:
            queryStreamWriter.write(userCommand + '#');

            //FLUSH the string:
            queryStreamWriter.flush();

        }catch(IOException e){
            System.out.println("Client: I/O error. " + e);
        }
    }



    public void reportServiceOutcome() {
        try {

            //Receive the ObjectOutputStream's result;
            InputStream outcomeStream = clientSocket.getInputStream();
            ObjectInputStream outcomeStreamReader = new ObjectInputStream(outcomeStream);
            serviceOutcome = (CachedRowSet) outcomeStreamReader.readObject();

            GridPane grid = (GridPane)thePrimaryStage.getScene().getRoot();
            ObservableList<Node> childrens = grid.getChildren();


            TableView<MyTableRecord> result = (TableView <MyTableRecord>) childrens.get(2);

            //'Childrens' is a container for all the child components that have been added to
            //'GridPane'
            //When we specify children '(1)' we are asking it to retrieve the second component
            //from the table (with a 0-based index)
            StringBuilder tmp = new StringBuilder();                                                                          //Value returned of 'age'...?

            serviceOutcome.beforeFirst();

            //Upon receiving this outcome, the method iterates over the outcome
            //to UPDATE the table CONTENTS:

            ObservableList<MyTableRecord> tmpRecords = result.getChildren();//<Here is the result - the TableView object
            tmpRecords.clear(); //CLEARS the table content
            while (this.serviceOutcome.next())
            {
              MyTableRecord myTableRecord = new MyTableRecord();
              myTableRecord.setAge(serviceOutcome.getString("age"));

              tmpRecords.add(myTableRecord);
            }

            result.setItems(tmpRecords);

            System.out.println("**** " + tmpRecords + "\n");

            System.out.println(tmp + "\n=================================================\n");

        }catch(IOException e){
            System.out.println("Client: I/O error. " + e);
        }catch(ClassNotFoundException e){
            System.out.println("Client: Unable to cast read object to CachedRowSet. " + e);
        }catch(SQLException e){
            System.out.println("Client: Can't retrieve requested attribute from result set. " + e);
        }
    }

    //Execute client
    public void execute(){
        //Prompt the user for an operation:
        GridPane grid = (GridPane) thePrimaryStage.getScene().getRoot();
        ObservableList<Node> childrens = grid.getChildren();
        TextField weaponInputBox = (TextField) childrens.get(1);
        TextField placeInputBox = (TextField) childrens.get(3);
        TextField timeInputBox = (TextField) childrens.get(5);

        //Build user message command
        userCommand = weaponInputBox.getText() + ";" + placeInputBox.getText() + ";" + timeInputBox();


        //Request service
        try{

            //Initializes the socket
            this.initializeSocket();

            //Request service
            this.requestService();

            //Report user outcome of service
            this.reportServiceOutcome();

            //Close the connection with the server
            this.clientSocket.close();

        }catch(Exception e)
        {// Raised if connection is refused or other technical issue
            System.out.println("Client: Exception " + e);
        }
    }




    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Cluedo Database Client");

        //Create a GridPane container
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(5);
        grid.setHgap(5);


        //Add the input boxes
        Label weaponLabel = new Label("Weapon:");
        GridPane.setConstraints(weaponLabel, 0, 0);
        grid.getChildren().add(weaponLabel);

        TextField weaponInputBox = new TextField ();
        weaponInputBox.setPromptText("Weapon");
        weaponInputBox.setPrefColumnCount(20);
        GridPane.setConstraints(weaponInputBox, 1, 0);
        grid.getChildren().add(weaponInputBox);

        Label placeLabel = new Label("Place:");
        GridPane.setConstraints(placeLabel, 0, 1);
        grid.getChildren().add(placeLabel);

        TextField placeInputBox = new TextField ();
        placeInputBox.setPromptText("Place");
        placeInputBox.setPrefColumnCount(30);
        GridPane.setConstraints(placeInputBox, 1, 1);
        grid.getChildren().add(placeInputBox);

        Label timeLabel = new Label("Time:");
        GridPane.setConstraints(timeLabel, 0, 2);
        grid.getChildren().add(timeLabel);

        TextField timeInputBox = new TextField ();
        timeInputBox.setPromptText("08:00");
        timeInputBox.setPrefColumnCount(5);
        GridPane.setConstraints(timeInputBox, 1, 2);
        grid.getChildren().add(timeInputBox);

        //Add the service request button
        Button btn = new Button();
        btn.setText("Request Database Service");
        btn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                me.execute();
            }
        });
        GridPane.setConstraints(btn, 0, 3, 2, 1);
        grid.getChildren().add(btn);

        //Add the output box
        TableView<MyTableRecord> outputBox = new TableView<MyTableRecord>();
        TableColumn<MyTableRecord,String> ageCol     = new TableColumn<MyTableRecord,String>("Age");
        ageCol.setCellValueFactory(new PropertyValueFactory("age"));
        //^ ALL DONE ALREADY (only needed one TableView column)

        @SuppressWarnings("unchecked") ObservableList<TableColumn<MyTableRecord,?>> tmp = outputBox.getColumns();
        tmp.addAll(ageCol);
        //Leaving this type unchecked by now... It may be convenient to compile with -Xlint:unchecked for details.

        GridPane.setConstraints(outputBox, 0, 4, 2, 1); //<why is this '4'?
        grid.getChildren().add(outputBox);

        primaryStage.setScene(new Scene(grid, 505, 505));
        primaryStage.show();


        thePrimaryStage = primaryStage;


    }




    public static void main (String[] args) {
        launch(args);
        System.out.println("Client: Finished.");
        System.exit(0);
    }
}