module com.example.resitcleansww2cluedoappfparris {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql.rowset;


    opens com.example.resitcleansww2cluedoappfparris to javafx.fxml;
    exports com.example.resitcleansww2cluedoappfparris;
}