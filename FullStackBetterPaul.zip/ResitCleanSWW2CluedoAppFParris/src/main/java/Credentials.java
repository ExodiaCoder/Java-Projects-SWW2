public class Credentials {
    //JDBC connection:
    public static final String USERNAME = "francescaparris";      //Optional to put own credentials - they're connecting
    public static final String PASSWORD = "Spaghetti582";          //with their own credentials so it doesn't really matter
    public static final String URL = "jdbc:postgresql://localhost:5432/FSAD2023_Resit";   //Client-server connection
    public static final String HOST = "127.0.0.1"; //localhost
    public static final int PORT = 9994;


//ALL DONE ! (Nothing you need to do here.)

    //This '9994' -is NOT THE PORT IN POSTGRES,
    //-but the port at which the ResitDatabaseServer is 'LISTENING'

    //'localhost:5432' part is where the port number for PostgreSQL is in the URL (5432) (what the server 'listens' on)
}

